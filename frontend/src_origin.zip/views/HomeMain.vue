<template>
  <HelloWorld />
</template>

<script setup>
import HelloWorld from "@/components/HelloWorld.vue";
</script>
