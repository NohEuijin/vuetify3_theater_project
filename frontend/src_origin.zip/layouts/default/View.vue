<!-- eslint-disable vue/multi-word-component-names -->
<template>
  <v-main>
    <router-view />
  </v-main>
</template>

<script setup>
  //
</script>
